SET SQL_SAFE_UPDATES = 0;

UPDATE edmscheduler.jobtaskarg SET arg_value = 1002 WHERE arg_name = 'client_id' and arg_value = 1008;
UPDATE edmscheduler.jobtaskarg SET arg_value = 1001 WHERE arg_name = 'client_id' and arg_value = 1007;

COMMIT;


